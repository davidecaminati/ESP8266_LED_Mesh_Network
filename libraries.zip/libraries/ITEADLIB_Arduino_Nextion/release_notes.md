# Release Notes

--------------------------------------------------------------------------------

# Release v0.9.0

  - version: v0.9.0
  - base: v0.7.0
  
## Brief

Support all components in Nextion Editor v0.38. 

## Details

Added APIs of new attrubutes and components supported by Nextion Editor v0.38.


# Release v0.7.0

  - version: v0.7.0
  - base: no base version
  - author: Wu Pengfei <pengfei.wu@itead.cc>
  - date: 8/20/2015 13:17:20 

## Brief

Support all components in Nextion Editor v0.26. 

## Details

First release. 


--------------------------------------------------------------------------------

# The End!

--------------------------------------------------------------------------------
